package testServlet;



import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.annotation.*;

@WebServlet("/testServlet/consultaPersonaPlus")
public class ConsultaPersonaPlus extends HttpServlet{

	public void doGet(HttpServletRequest request,
	HttpServletResponse response)
	throws ServletException, IOException
	{
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		
		out.println("<HEAD><TITLE> Query Result</TITLE></HEAD>");
		out.println("<BODY>");
		String persontype = request.getParameter("tipoPersona");
		String name = request.getParameter("nombre");
		String apellido = request.getParameter("apellido");
		String documento = request.getParameter("documento");
		//String number = request.getParameter("nombre");
		out.println("<table BORDER COLS=4>");
		out.println(" <tr> <td>ID</td> <td>Nombre: </td>" +
					"<td>Apellido: </td>" +
				" <td>Departamento</td> </tr>");
		int ID;
		String nombre;
		String ape;
		String depto;
		if(persontype.equals("estudiante") && name.equals("Juan") && apellido.equals("Perez") && documento.equals("8888")) {
			ID = 8888;
			nombre = "Juan";
			ape = "Perez";
			depto = "MACC";
			
			
		}
		else {
			ID = 2222;
			nombre = "Renato";
			ape = "Sanchez";
			depto = "MACC";
		}
		out.println("<tr> <td>" + ID + "</td>" +
				"<td>" + nombre + "</td>" +
				"<td>" + ape + "</td>" +
				"<td>" + depto + "</td></tr>");
			
		out.println("</table>");
		out.println("</BODY>");
		out.close();
	}
}