package testServlet;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;


public class conexion {
    public static void main(String[] args) {
    	//Intenta establecer conexi�n
    	System.out.println("Estableciendo conexion...");
        try (Connection conexion = DriverManager.getConnection("jdbc:postgresql://localhost:5432/taller4_base1", "postgres", "postgres")) {
 
            
            System.out.println("Conexion con la base de datos establecida (PostgreSQL)");
            Statement statement = conexion.createStatement();
                   
          //Ejemplo inserci�n
           // System.out.println("Consultando la base de datos...");
            //statement.executeUpdate("insert into curso values ('005', 'probabilidad', 'MACC', 3);");
            
          //Ejemplo consulta
            String consulta = " select A.nombres,A.apellidos,A.id from (select * from estudiante join (select * from estcursos natural join curso) as A on id = estid)as A where A.nombre = 'programacion';";
            System.out.println("Consultando la base de datos...");
            ResultSet resultSet = statement.executeQuery(consulta);
            
            System.out.println("Imprimiendo resultados...");
            System.out.printf("%-30.30s  %-30.30s %-30.30s%n", "Nombre", "Apellido", "ID");
            //int totCreditos = 0;
            while (resultSet.next()) {
                System.out.printf("%-30.30s  %-30.30s  %-30.30s%n", resultSet.getString("nombres"), resultSet.getString("apellidos"), resultSet.getString("id"));
                //totCreditos += Integer.parseInt(resultSet.getString("creditos"));
            }
            //System.out.printf("# creditos totales: %d%n", totCreditos);
            
            
        } catch (SQLException e) {
            System.out.println("Conexi�n fallida");
            e.printStackTrace();
        }
    }
}
    	
    	/*
    	//Intenta establecer conexi�n
    	System.out.println("Estableciendo conexi�n...");
        try (Connection conexion = DriverManager.getConnection("jdbc:postgresql://localhost:5432/taller4_base1", "postgres", "postgres")) {
 
            
            System.out.println("Conexion con la base de datos establecida (PostgreSQL)");
            Statement statement = conexion.createStatement();
        
           
            
           
          //Ejemplo inserci�n
           // System.out.println("Consultando la base de datos...");
            //statement.executeUpdate("insert into curso values ('005', 'probabilidad', 'MACC', 3);");
            
          //Ejemplo consulta
            System.out.println("Consultando la base de datos...");
            ResultSet resultSet = statement.executeQuery("select nombre, nombre_unid, creditos from public.curso where nombre_unid = 'MACC';");
            
            System.out.println("Imprimiendo resultados...");
            System.out.printf("%-30.30s  %-30.30s %-30.30s%n", "Nombre", "Unidad", "# creditos");
            int totCreditos = 0;
            while (resultSet.next()) {
                System.out.printf("%-30.30s  %-30.30s  %-30.30s%n", resultSet.getString("nombre"), resultSet.getString("nombre_unid"), resultSet.getString("creditos"));
                totCreditos += Integer.parseInt(resultSet.getString("creditos"));
            }
            System.out.printf("# cr�ditos totales: %d%n", totCreditos);
            
            
        } catch (SQLException e) {
            System.out.println("Conexi�n fallida");
            e.printStackTrace();
        }
    }

}
*/


 
