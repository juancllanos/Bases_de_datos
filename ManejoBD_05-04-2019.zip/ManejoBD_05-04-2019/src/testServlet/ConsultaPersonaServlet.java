package testServlet;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.annotation.*;


@WebServlet("/testServlet/consultaPersona")
public class ConsultaPersonaServlet extends HttpServlet{

	public void doGet(HttpServletRequest request,
	HttpServletResponse response)
	throws ServletException, IOException
	{
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		
		out.println("<HEAD><TITLE> Query Result</TITLE></HEAD>");
		out.println("<BODY>");
		String persontype = request.getParameter("tipoPersona");
		String name = request.getParameter("nombre");
		out.println("<table BORDER COLS=3>");
		out.println(" <tr> <td>ID</td> <td>Nombre</td>" +
				" <td>Apellido</td> </tr>");
		String ID;
		String nombre;
		String apellido;
		
    	//Intenta establecer conexi�n
    	System.out.println("Estableciendo conexion...");
        try (Connection conexion = DriverManager.getConnection("jdbc:postgresql://localhost:5432/taller4_base1", "postgres", "postgres")) {
 
            
            System.out.println("Conexion con la base de datos establecida (PostgreSQL)");
            Statement statement = conexion.createStatement();
                   
          //Ejemplo inserci�n
           // System.out.println("Consultando la base de datos...");
            //statement.executeUpdate("insert into curso values ('005', 'probabilidad', 'MACC', 3);");
            
          //Ejemplo consulta
            /*
            String consulta = " select A.nombres,A.apellidos,A.id from (select * from estudiante join "
            		+ "(select * from estcursos natural join curso) "
            		+ "as A on id = estid)as A where A.nombre = '" + name + "';";
            		*/
            String consulta = " select A.nombres,A.apellidos,A.id from (select * from estudiante join (select * from estcursos natural join curso) as A on id = estid)as A where A.nombre = '"+name+"';";
            System.out.println("Consultando la base de datos...");
            System.out.println(consulta);
            ResultSet resultSet = statement.executeQuery(consulta);
            
            System.out.println("Imprimiendo resultados...");
            System.out.printf("%-30.30s  %-30.30s %-30.30s%n", "Nombre", "Apellido", "ID");
            while (resultSet.next()) {
                System.out.printf("%-30.30s  %-30.30s  %-30.30s%n", resultSet.getString("nombres"), resultSet.getString("apellidos"), resultSet.getString("id"));
                ID = resultSet.getString("id");
                nombre = resultSet.getString("nombres");
                apellido = resultSet.getString("apellidos");
                
        		out.println("<tr> <td>" + ID + "</td>" +
        				"<td>" + nombre + "</td>" +
        				"<td>" + apellido + "</td></tr>");
                //totCreditos += Integer.parseInt(resultSet.getString("creditos"));
            }
            //System.out.printf("# creditos totales: %d%n", totCreditos);
            
            
        } catch (SQLException e) {
            System.out.println("Conexion fallida");
            e.printStackTrace();
        }
		
			
		out.println("</table>");
		out.println("</BODY>");
		out.close();
		
		
		
	}
}



