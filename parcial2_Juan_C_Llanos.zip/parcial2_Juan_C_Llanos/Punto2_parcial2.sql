create table cliente (
	id numeric(10,0),
	nombres varchar(15),
	apellidos varchar(20),
	primary key(id)
);


create table membresia (
	tipo varchar(20),
	primary key(tipo)
);

create table sesion_grupal (
	id numeric(10,0),
	fecha date,
	hora time  ,
	sala varchar(15),
	actividad varchar(20),
	id_ins numeric(10,0),
	capacidad int,
	primary key(id)
);

create table sesion_individual (
	id numeric(10,0),
	fecha date,
	hora time ,
	sala varchar(15),
	req_entren bool,
	primary key(id)
);

create table realiza (
	id numeric(10,0),
	id_ses numeric (10,0),
	primary key(id,id_ses)
);

create table tiene (
	id numeric(10,0),
	num_afi numeric(10,0),
	fecha_ini date,
	fecha_fin date,
	primary key(id)
);

